1. First run "start server.bat"
2. Run "start client localhost.bat"
3. If you want you can run 2 clinet by running "start client localhost.bat"

If you have some problems close all opened windows and do 1 2 step one more time.